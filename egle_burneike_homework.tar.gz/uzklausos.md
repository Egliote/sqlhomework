### Uzklausos

#1
Irasas i duomenu baze "students" lentelei: pvz:

```insert into students (full_name, age, phone_number, email) values ('Eglė Burneikė', 41, 868789588, 'egliote@outlook.com');```


#2
Irasas i duomenu baze "courses" lentelei: pvz:

```insert into courses (title, student_id, taken) values ('PHP Intro', 1, 1), ('Frontend Intro', 2, 1), ('Duomenu bazes Intro', 3, 0);```

